package ir.madarghavi.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Pink = Color(0xFFE98BA7)
private val DeepPink = Color(0xFFB94F70)
private val Cream = Color(0xFFFFF8FA)
private val Soft = Color(0xFFF8E8EE)
private val TextDark = Color(0xFF4A3A40)

data class Feature(val icon: String, val title: String, val subtitle: String)

private val features = listOf(
    Feature("👶", "کودک من", "رشد و مشخصات"),
    Feature("🍼", "تغذیه", "شیر و غذای کمکی"),
    Feature("😴", "خواب", "ثبت و پیگیری"),
    Feature("💉", "واکسن‌ها", "یادآوری"),
    Feature("🧸", "رشد و بازی", "فعالیت مناسب سن"),
    Feature("❤️", "مادر", "مراقبت از مادر"),
    Feature("🔔", "یادآوری‌ها", "کارهای مهم"),
    Feature("🚑", "راهنمای فوری", "علائم هشدار")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MadarGaviApp() }
    }
}

@Composable
fun MadarGaviApp() {
    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = DeepPink,
            secondary = Pink,
            background = Cream,
            surface = Color.White
        )
    ) {
        var selected by remember { mutableStateOf("خانه") }
        CompositionLocalProvider(LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(
                containerColor = Cream,
                bottomBar = {
                    NavigationBar(containerColor = Color.White) {
                        listOf("خانه" to "🏠", "کودک" to "👶", "مادر" to "❤️", "یادآوری" to "🔔").forEach {
                            NavigationBarItem(
                                selected = selected == it.first,
                                onClick = { selected = it.first },
                                icon = { Text(it.second, fontSize = 20.sp) },
                                label = { Text(it.first) }
                            )
                        }
                    }
                }
            ) { padding ->
                when (selected) {
                    "خانه" -> HomeScreen(padding) { selected = it }
                    "کودک" -> ChildScreen(padding)
                    "مادر" -> MotherScreen(padding)
                    else -> ReminderScreen(padding)
                }
            }
        }
    }
}

@Composable
fun HomeScreen(padding: PaddingValues, open: (String) -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text("مادر قوی", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = DeepPink)
        Text("همراه روزهای قشنگ مادری 🌷", color = TextDark, fontSize = 15.sp)
        Spacer(Modifier.height(18.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Soft),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(Modifier.padding(18.dp), horizontalAlignment = Alignment.End) {
                Text("امروز برای شما", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = TextDark)
                Spacer(Modifier.height(8.dp))
                Text("کوچولوی شما ۶ ماهه است. امروز یک فعالیت ساده برای تقویت نشستن و بازی با اسباب‌بازی‌های سبک انجام دهید.", color = TextDark)
            }
        }

        Spacer(Modifier.height(18.dp))
        Text("دسترسی سریع", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = TextDark)
        Spacer(Modifier.height(10.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.height(570.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(features) { f ->
                Card(
                    modifier = Modifier.fillMaxWidth().clickable { open(f.title) },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(
                        Modifier.padding(16.dp).fillMaxHeight(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(f.icon, fontSize = 32.sp)
                        Spacer(Modifier.height(8.dp))
                        Text(f.title, fontWeight = FontWeight.Bold, color = TextDark)
                        Text(f.subtitle, fontSize = 12.sp, color = Color.Gray, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
fun ChildScreen(padding: PaddingValues) {
    DetailScaffold(padding, "👶 کودک من") {
        InfoCard("سن کودک", "۶ ماه و ۱۲ روز")
        InfoCard("وزن ثبت‌شده", "۷.۲ کیلوگرم")
        InfoCard("قد ثبت‌شده", "۶۷ سانتی‌متر")
        InfoCard("پیشنهاد امروز", "بازی روی زمین با اسباب‌بازی‌های رنگی و امن.")
    }
}

@Composable
fun MotherScreen(padding: PaddingValues) {
    DetailScaffold(padding, "❤️ مراقبت از مادر") {
        InfoCard("آرامش امروز", "۱۰ دقیقه زمان برای استراحت و تنفس آرام.")
        InfoCard("تغذیه", "آب کافی، وعده‌های منظم و غذای متنوع.")
        InfoCard("یادآوری", "اگر احساس خستگی یا ناراحتی مداوم دارید، با پزشک یا ماما صحبت کنید.")
    }
}

@Composable
fun ReminderScreen(padding: PaddingValues) {
    DetailScaffold(padding, "🔔 یادآوری‌ها") {
        InfoCard("امروز", "ثبت خواب کودک — انجام نشده")
        InfoCard("فردا", "بررسی برنامه واکسن")
        InfoCard("این هفته", "ثبت وزن و قد کودک")
    }
}

@Composable
fun DetailScaffold(padding: PaddingValues, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text(title, fontSize = 27.sp, fontWeight = FontWeight.Bold, color = DeepPink)
        Spacer(Modifier.height(18.dp))
        content()
        Spacer(Modifier.height(16.dp))
        Text(
            "این بخش آموزشی است و جایگزین تشخیص یا درمان پزشکی نیست.",
            color = Color.Gray,
            fontSize = 12.sp,
            textAlign = TextAlign.Right,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun InfoCard(title: String, text: String) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column(Modifier.fillMaxWidth().padding(17.dp), horizontalAlignment = Alignment.End) {
            Text(title, fontWeight = FontWeight.Bold, color = TextDark, fontSize = 17.sp)
            Spacer(Modifier.height(7.dp))
            Text(text, color = TextDark, lineHeight = 23.sp)
        }
    }
}
