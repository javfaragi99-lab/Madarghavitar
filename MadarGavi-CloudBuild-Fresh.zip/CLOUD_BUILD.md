# ساخت APK فقط با گوشی

## 1. GitHub
یک Repository به نام `MadarGavi` بساز.

## 2. آپلود پروژه
محتویات این ZIP را در Repository قرار بده. مهم است که فایل `.github/workflows/build-apk.yml` هم آپلود شود.

## 3. اجرای Build
در صفحه Repository:
`Actions` → `Build Madar Gavi APK` → `Run workflow`

## 4. دریافت APK
بعد از سبز شدن اجرای Workflow:
صفحه اجرای Workflow را باز کن → بخش `Artifacts` → `MadarGavi-debug-apk`

فایل ZIP مربوط به Artifact را دانلود و باز کن. داخل آن `app-debug.apk` قرار دارد.

## 5. نصب
`app-debug.apk` را روی گوشی باز کن و در صورت درخواست، اجازه نصب از این منبع را فعال کن.

این APK نسخه آزمایشی (debug) است و برای انتشار در Google Play نیاز به نسخه release و امضای مناسب دارد.
